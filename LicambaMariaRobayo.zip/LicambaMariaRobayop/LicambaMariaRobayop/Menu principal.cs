﻿/*
 * Creado por SharpDevelop.
 * Usuario: ALFONSO
 * Fecha: 8/06/2019
 * Hora: 5:51 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace LicambaMariaRobayop
{
	/// <summary>
	/// Description of Menu_principal.
	/// </summary>
	public partial class Menu_principal : Form
	{
		public Menu_principal()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
